#!/bin/sh
set -eu
C=/runtime-config/hermes.env
if [ -f "$C" ]; then
  cp "$C" /opt/data/.env
  chmod 600 /opt/data/.env || true
fi
