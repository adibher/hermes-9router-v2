# Railway notes

Recommended production pattern on Railway:

- 9Router service
- Hermes service
- optional setup service

Railway does not give application containers access to the Docker socket, so the Web Setup panel cannot restart sibling services there. Use Railway Variables for production secrets and redeploy/restart after changes.

Hermes documents Telegram webhook mode for Railway/cloud platforms. Configure the public HTTPS webhook URL and `TELEGRAM_WEBHOOK_SECRET`; otherwise polling mode keeps the service running continuously.
