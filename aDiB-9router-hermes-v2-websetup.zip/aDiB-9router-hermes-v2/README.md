# aDiB 9Router + Hermes Agent v2 — Web Setup

A small deployment wrapper around the official 9Router and Hermes Agent Docker images.

## What v2 adds

- Password-protected Web Setup panel
- Persistent configuration volume
- 9Router initial password + security secrets
- Telegram bot token
- Telegram allowed user IDs
- Telegram home channel
- Telegram webhook settings
- Telegram proxy
- Hermes API/gateway key fields
- Hermes → 9Router OpenAI-compatible endpoint
- Save + restart on Docker Compose/VPS
- No real secrets in Git

9Router officially exposes Docker images and documents `JWT_SECRET`, `INITIAL_PASSWORD`, `DATA_DIR`, `API_KEY_SECRET`, `MACHINE_ID_SALT`, `REQUIRE_API_KEY`, etc. The router uses port 20128 and persists SQLite under its data directory.

Hermes officially supports Docker, its `gateway run` command, Telegram environment variables, and webhook mode for cloud deployments.

## Local / VPS

```bash
cp .env.example .env
# edit .env and change SETUP_PASSWORD
docker compose up -d --build
```

Open:

```text
http://SERVER:8080
```

The Setup Panel credentials are the `SETUP_USERNAME` and `SETUP_PASSWORD` from `.env`.

After saving, configuration is stored in the persistent `app-config` volume. **Save + restart** restarts the 9Router and Hermes containers so they reread the configuration.

## Telegram

Create a bot with `@BotFather` and put its token into the panel. Put your numeric Telegram user ID in `Allowed user IDs`. Multiple IDs can be comma-separated.

For cloud deployments such as Railway, Hermes recommends webhook mode:

```text
TELEGRAM_WEBHOOK_URL=https://YOUR-DOMAIN/telegram
TELEGRAM_WEBHOOK_SECRET=<strong-random-secret>
TELEGRAM_WEBHOOK_PORT=8443
```

## 9Router connection

The default internal URL is:

```text
http://9router:20128/v1
```

If 9Router's `REQUIRE_API_KEY` is enabled, create an endpoint key in the 9Router dashboard and enter it in the panel. The router's internal `API_KEY_SECRET` is a different secret.

## Railway

Railway can deploy the services as Docker services, but the Setup Panel cannot use Docker socket operations there. Therefore the panel can save configuration, but **Save + restart** will not restart sibling Railway services. Use Railway service variables/redeploy for production, or use a VPS/Coolify if you want the one-click restart behavior.

Also note that Hermes' own docs distinguish secrets (`~/.hermes/.env`) from normal config and warn against exposing the dashboard without authentication.

## Security

- Change `SETUP_PASSWORD` before deployment.
- Do not commit `.env`.
- Do not expose port 8080 publicly without HTTPS/reverse-proxy protection.
- Keep `TELEGRAM_ALLOWED_USERS` restrictive.
- Do not enable Telegram allow-all for production.
