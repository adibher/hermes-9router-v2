#!/usr/bin/env bash
set -euo pipefail
[[ -f .env ]] || cp .env.example .env
docker compose up -d --build
docker compose ps
echo "Setup panel: http://localhost:${SETUP_PORT:-8080}"
