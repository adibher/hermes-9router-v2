#!/bin/sh
set -eu
C="${CONFIG_FILE:-/config/settings.json}"
if [ -f "$C" ]; then
  get() { node -e 'const fs=require("fs");const x=JSON.parse(fs.readFileSync(process.argv[1])); console.log(x.ninerouter[process.argv[2]] ?? "")' "$C" "$1"; }
  export JWT_SECRET="$(get jwt_secret)"
  export INITIAL_PASSWORD="$(get initial_password)"
  export API_KEY_SECRET="$(get api_key_secret)"
  export MACHINE_ID_SALT="$(get machine_id_salt)"
  export ENABLE_REQUEST_LOGS="$(get enable_request_logs)"
  export AUTH_COOKIE_SECURE="$(get auth_cookie_secure)"
  export REQUIRE_API_KEY="$(get require_api_key)"
  export BASE_URL="$(get base_url)"
  export CLOUD_URL="$(get cloud_url)"
fi
exec "$@"
