import base64,hmac,json,os,secrets,subprocess
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs

CONFIG=Path('/config/settings.json'); HENV=Path('/config/hermes.env'); CONFIG.parent.mkdir(parents=True,exist_ok=True)
USER=os.getenv('SETUP_USERNAME','admin'); PASSWORD=os.getenv('SETUP_PASSWORD','CHANGE_ME'); PORT=int(os.getenv('SETUP_PORT','8080'))
DEFAULT={
 'ninerouter':{'initial_password':'','jwt_secret':'','api_key_secret':'','machine_id_salt':'','enable_request_logs':False,'auth_cookie_secure':False,'require_api_key':True,'base_url':'http://localhost:20128','cloud_url':'https://9router.com'},
 'hermes':{'telegram_bot_token':'','telegram_allowed_users':'','telegram_home_channel':'','telegram_home_channel_name':'aDiB Hermes','telegram_webhook_url':'','telegram_webhook_port':'8443','telegram_webhook_secret':'','telegram_proxy':'','gateway_allowed_users':'','api_server_key':'','router_base_url':'http://9router:20128/v1','router_api_key':'','model':''}}

def load():
    if CONFIG.exists():
        try: return merge(DEFAULT,json.loads(CONFIG.read_text()))
        except Exception: pass
    x=json.loads(json.dumps(DEFAULT)); x['ninerouter']['jwt_secret']=secrets.token_urlsafe(48); x['ninerouter']['api_key_secret']=secrets.token_urlsafe(48); x['ninerouter']['machine_id_salt']=secrets.token_urlsafe(48); save(x); return x

def merge(a,b):
    x=json.loads(json.dumps(a))
    for k,v in b.items(): x[k]=merge(x[k],v) if isinstance(v,dict) and isinstance(x.get(k),dict) else v
    return x

def save(x):
    tmp=CONFIG.with_suffix('.tmp'); tmp.write_text(json.dumps(x,indent=2)); os.chmod(tmp,0o600); tmp.replace(CONFIG)

def dotenv_quote(v):
    v=str(v).replace('\\','\\\\').replace('"','\\"').replace('\n','\\n')
    return '"'+v+'"'

def write_hermes_env(x):
    h=x['hermes']; pairs={
      'TELEGRAM_BOT_TOKEN':h['telegram_bot_token'],'TELEGRAM_ALLOWED_USERS':h['telegram_allowed_users'],
      'TELEGRAM_HOME_CHANNEL':h['telegram_home_channel'],'TELEGRAM_HOME_CHANNEL_NAME':h['telegram_home_channel_name'],
      'TELEGRAM_WEBHOOK_URL':h['telegram_webhook_url'],'TELEGRAM_WEBHOOK_PORT':h['telegram_webhook_port'],
      'TELEGRAM_WEBHOOK_SECRET':h['telegram_webhook_secret'],'TELEGRAM_PROXY':h['telegram_proxy'],
      'GATEWAY_ALLOWED_USERS':h['gateway_allowed_users'],'API_SERVER_KEY':h['api_server_key'],
      'OPENAI_BASE_URL':h['router_base_url'],'OPENAI_API_KEY':h['router_api_key']}
    lines=[f'{k}={dotenv_quote(v)}' for k,v in pairs.items() if v!='']
    tmp=HENV.with_suffix('.tmp'); tmp.write_text('\n'.join(lines)+'\n'); os.chmod(tmp,0o600); tmp.replace(HENV)

def auth(headers):
    try:
      a=headers.get('Authorization',''); raw=base64.b64decode(a.split()[1]).decode(); u,p=raw.split(':',1)
      return hmac.compare_digest(u,USER) and hmac.compare_digest(p,PASSWORD)
    except Exception: return False

def esc(s): return str(s).replace('&','&amp;').replace('<','&lt;').replace('>','&gt;').replace('"','&quot;')
def inp(n,label,v,typ='text',secret=False): return f'<label>{label}<input name="{n}" type="{typ}" value="{esc(v)}" autocomplete="{("new-password" if secret else "off")}"></label>'
def chk(n,label,v): return f'<label class="check"><input name="{n}" type="checkbox" {"checked" if v else ""}>{label}</label>'

def page(x,msg=''):
 n,h=x['ninerouter'],x['hermes']
 return f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>aDiB AI Setup</title><style>
body{{margin:0;background:#090e1a;color:#edf2ff;font:15px system-ui}}main{{max-width:1000px;margin:35px auto;padding:18px}}header,.card{{background:#111a2b;border:1px solid #293753;border-radius:18px;padding:22px;margin-bottom:18px}}.grid{{display:grid;grid-template-columns:1fr 1fr;gap:18px}}h1{{margin:0 0 8px}}h2{{margin-top:0}}label{{display:block;margin:13px 0;font-weight:700}}input{{display:block;width:100%;box-sizing:border-box;padding:11px;margin-top:6px;border-radius:9px;border:1px solid #3b4967;background:#080d16;color:#fff}}.check input{{display:inline;width:auto}}button{{padding:12px 18px;border:0;border-radius:10px;font-weight:800;cursor:pointer}}.ok{{background:#123b29;padding:12px;border-radius:10px;margin-top:12px}}code{{background:#080d16;padding:2px 6px;border-radius:5px}}@media(max-width:760px){{.grid{{grid-template-columns:1fr}}}}</style></head><body><main><header><h1>aDiB AI Stack</h1><p>9Router + Hermes Agent Web Setup. Configuration and secrets are stored in a persistent volume.</p>{('<div class="ok">'+esc(msg)+'</div>') if msg else ''}</header><form method="post" action="/save"><div class="grid">
<section class="card"><h2>9Router</h2>{inp('ninerouter_initial_password','Initial password',n['initial_password'],'password',True)}{inp('ninerouter_jwt_secret','JWT secret',n['jwt_secret'],'password',True)}{inp('ninerouter_api_key_secret','API key secret',n['api_key_secret'],'password',True)}{inp('ninerouter_machine_id_salt','Machine ID salt',n['machine_id_salt'],'password',True)}{chk('enable_request_logs','Enable request logs',n['enable_request_logs'])}{chk('auth_cookie_secure','Secure auth cookies / HTTPS',n['auth_cookie_secure'])}{chk('require_api_key','Require API key on /v1',n['require_api_key'])}</section>
<section class="card"><h2>Telegram / Hermes</h2>{inp('telegram_bot_token','Bot token (@BotFather)',h['telegram_bot_token'],'password',True)}{inp('telegram_allowed_users','Allowed user IDs',h['telegram_allowed_users'])}{inp('telegram_home_channel','Home channel/chat ID',h['telegram_home_channel'])}{inp('telegram_home_channel_name','Home channel name',h['telegram_home_channel_name'])}{inp('telegram_webhook_url','Webhook URL',h['telegram_webhook_url'],'url')}{inp('telegram_webhook_port','Webhook local port',h['telegram_webhook_port'])}{inp('telegram_webhook_secret','Webhook secret',h['telegram_webhook_secret'],'password',True)}{inp('telegram_proxy','Telegram proxy',h['telegram_proxy'])}</section>
<section class="card"><h2>Hermes security</h2>{inp('gateway_allowed_users','Gateway allowed users',h['gateway_allowed_users'])}{inp('api_server_key','Hermes API server key',h['api_server_key'],'password',True)}{inp('model','Preferred model',h['model'])}</section>
<section class="card"><h2>9Router endpoint</h2>{inp('router_base_url','OpenAI-compatible Base URL',h['router_base_url'])}{inp('router_api_key','9Router endpoint API key',h['router_api_key'],'password',True)}<p>Docker default: <code>http://9router:20128/v1</code></p></section>
</div><p><button type="submit">Save</button> <button type="submit" formaction="/save-restart">Save + restart</button></p></form></main></body></html>'''

class Handler(BaseHTTPRequestHandler):
 def send(self,s,c=200): self.send_response(c); self.send_header('Content-Type','text/html;charset=utf-8'); self.send_header('Cache-Control','no-store'); self.end_headers(); self.wfile.write(s.encode())
 def unauth(self): self.send_response(401); self.send_header('WWW-Authenticate','Basic realm="aDiB Setup"'); self.end_headers()
 def do_GET(self):
  if not auth(self.headers): return self.unauth()
  self.send(page(load()))
 def do_POST(self):
  if not auth(self.headers): return self.unauth()
  q=parse_qs(self.rfile.read(int(self.headers.get('Content-Length',0))).decode(),keep_blank_values=True); x=load(); n,h=x['ninerouter'],x['hermes']
  def v(k,d=''): return q.get(k,[d])[0].strip()
  for k in ['initial_password','jwt_secret','api_key_secret','machine_id_salt']:
   n[k]=v('ninerouter_'+k,n[k]) or n[k]
  n['enable_request_logs']='enable_request_logs' in q; n['auth_cookie_secure']='auth_cookie_secure' in q; n['require_api_key']='require_api_key' in q
  for k in ['telegram_bot_token','telegram_allowed_users','telegram_home_channel','telegram_home_channel_name','telegram_webhook_url','telegram_webhook_port','telegram_webhook_secret','telegram_proxy','gateway_allowed_users','api_server_key','router_base_url','router_api_key','model']:
   h[k]=v(k,h[k])
  save(x); write_hermes_env(x); msg='Settings saved.'
  if self.path=='/save-restart':
   try:
    r=subprocess.run(['docker','restart','adib-9router','adib-hermes'],capture_output=True,text=True,timeout=60)
    msg += ' Services recreated.' if r.returncode==0 else ' Saved, but service restart failed; check Docker logs.'
   except Exception: msg += ' Saved; automatic restart is unavailable on this platform.'
  self.send(page(x,msg))

ThreadingHTTPServer(('0.0.0.0',PORT),Handler).serve_forever()
